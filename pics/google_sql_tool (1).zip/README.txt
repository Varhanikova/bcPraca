Google SQL Command Line Tool.
https://developers.google.com/cloud-sql/docs/commandline

Release 10.
Release Date: 2012-04-19
Changes:
  * Support upper case command names in addition to lower case.  For example,
    "DELIMITER" now works in addition to "delimiter".
  * Upgrade to Google APIs Client Library for Java v1.8
  * Fix issue where you could not type in an OAuth2 access code, only pasting
    it worked.
  * Include error code and sqlstate in SQLException messages displayed from
    sql.sh.
  * Don't cap the lob (blob,clob) size @10 chars, but rather use the real
    width of the data. Also fixed a bug where lobs were right padded like
    numbers instead of being left padded.

Release 9.
Release Date: 2011-10-03
Changes:
  * Set socket read timeout to 400s from no timeout.
  * If --user is specified and --pass is not, prompt the console for the password.
    Otherwise you can use --pass="" to mean no password.

Release 8.
Release Date: 2011-08-10
Changes:
  * Cache OAuth2 accessTokens in addition to refreshTokens to minimize network
    traffic on opening new connections.
  * Calculate time elapsed in sql.sh as the time elapsed executing the query,
    not the time it took to execute the query and display the rows to the
    console.
  * Log text of the page when an error page is returned from the OAuth2 server.

Release 7.
Release Date: 2011-07-13
Changes:
  * Fix incorrect setting of connect() deadline.

Release 6.
Release Date: 2011-06-30
Changes:
  * Fix sending password from the commandline tool.
  * Restore using no-deadline for the Google API server socket call that
    used to be how v4 and earlier worked. Also added a 60s (up from 20s
    in the new code) deadline on connect().
  * Various internal cleanups.

Release 5.
Release Date: 2011-06-02
Changes:
  * Includes support for other command line tools connecting through JDBC,
    using driver class com.google.cloud.sql.Driver.
    See https://code.google.com/apis/sqlservice/usingsquirrel.html

Release 4.
Release Date: 2011-05-26
Changes:
  * Include link to the documentation when the exception message tells
    you that the refresh token is not valid so you know how to delete it.
  * Set jdbcCompliantTruncation=false in the sql.sh tool to match
    most command line tools.

Release 3.
Release Date: 2011-05-18.
Changes:
  * Fixed issue where the OAuth2 access token was not getting properly
    refreshed in all cases.
  * Fixed a couple of OAuth2 token issues by returning better error messages
    and also making sure that OAuth2 issues are categorized as connection
    related issues (which means the connection is borked and just give up).
  * Use command -v to determine where java exists if JAVA_HOME is not set.
    See http://pubs.opengroup.org/onlinepubs/9699919799/utilities/command.html
  * Disable keepAlive query while a query is executing, and don't timeout a
    connection while an existing query is executing.
  * Fix the tool to use streaming resultsets so larger resultsets can be
    fetched.
  * Throw subclasses of SQLException when possible using the application error
    code from the server. When getting a SQLRecoverableException (which dispite
    it's name means you have to disconnect and reconnect to recover from the
    error) in the sql prompt, tell the user and exit.
  * Made warnings display the count when it has warnings.
    Also made displaying the warnings off by default
    (like most other db tools do).
    Fixed a bug where the keepalive query would eat the warnings, so that now
    uses it's own connection.
  * Minor logging fix when exiting tool with a timeout.

Release 2.
Release Date: 2011-03-31.
Changes:
  * Exit with a non-zero error code when sql.sh crashes.
  * Fix script to work with POSIX compliant dash/ash and not just bash.

Usage:
       google_sql.sh <instance> [database]


Licenses:
========================================================================
Jackson:

                                   Apache License
                             Version 2.0, January 2004
                          http://www.apache.org/licenses/

     TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

     1. Definitions.

        "License" shall mean the terms and conditions for use, reproduction,
        and distribution as defined by Sections 1 through 9 of this document.

        "Licensor" shall mean the copyright owner or entity authorized by
        the copyright owner that is granting the License.

        "Legal Entity" shall mean the union of the acting entity and all
        other entities that control, are controlled by, or are under common
        control with that entity. For the purposes of this definition,
        "control" means (i) the power, direct or indirect, to cause the
        direction or management of such entity, whether by contract or
        otherwise, or (ii) ownership of fifty percent (50%) or more of the
        outstanding shares, or (iii) beneficial ownership of such entity.

        "You" (or "Your") shall mean an individual or Legal Entity
        exercising permissions granted by this License.

        "Source" form shall mean the preferred form for making modifications,
        including but not limited to software source code, documentation
        source, and configuration files.

        "Object" form shall mean any form resulting from mechanical
        transformation or translation of a Source form, including but
        not limited to compiled object code, generated documentation,
        and conversions to other media types.

        "Work" shall mean the work of authorship, whether in Source or
        Object form, made available under the License, as indicated by a
        copyright notice that is included in or attached to the work
        (an example is provided in the Appendix below).

        "Derivative Works" shall mean any work, whether in Source or Object
        form, that is based on (or derived from) the Work and for which the
        editorial revisions, annotations, elaborations, or other modifications
        represent, as a whole, an original work of authorship. For the purposes
        of this License, Derivative Works shall not include works that remain
        separable from, or merely link (or bind by name) to the interfaces of,
        the Work and Derivative Works thereof.

        "Contribution" shall mean any work of authorship, including
        the original version of the Work and any modifications or additions
        to that Work or Derivative Works thereof, that is intentionally
        submitted to Licensor for inclusion in the Work by the copyright owner
        or by an individual or Legal Entity authorized to submit on behalf of
        the copyright owner. For the purposes of this definition, "submitted"
        means any form of electronic, verbal, or written communication sent
        to the Licensor or its representatives, including but not limited to
        communication on electronic mailing lists, source code control systems,
        and issue tracking systems that are managed by, or on behalf of, the
        Licensor for the purpose of discussing and improving the Work, but
        excluding communication that is conspicuously marked or otherwise
        designated in writing by the copyright owner as "Not a Contribution."

        "Contributor" shall mean Licensor and any individual or Legal Entity
        on behalf of whom a Contribution has been received by Licensor and
        subsequently incorporated within the Work.

     2. Grant of Copyright License. Subject to the terms and conditions of
        this License, each Contributor hereby grants to You a perpetual,
        worldwide, non-exclusive, no-charge, royalty-free, irrevocable
        copyright license to reproduce, prepare Derivative Works of,
        publicly display, publicly perform, sublicense, and distribute the
        Work and such Derivative Works in Source or Object form.

     3. Grant of Patent License. Subject to the terms and conditions of
        this License, each Contributor hereby grants to You a perpetual,
        worldwide, non-exclusive, no-charge, royalty-free, irrevocable
        (except as stated in this section) patent license to make, have made,
        use, offer to sell, sell, import, and otherwise transfer the Work,
        where such license applies only to those patent claims licensable
        by such Contributor that are necessarily infringed by their
        Contribution(s) alone or by combination of their Contribution(s)
        with the Work to which such Contribution(s) was submitted. If You
        institute patent litigation against any entity (including a
        cross-claim or counterclaim in a lawsuit) alleging that the Work
        or a Contribution incorporated within the Work constitutes direct
        or contributory patent infringement, then any patent licenses
        granted to You under this License for that Work shall terminate
        as of the date such litigation is filed.

     4. Redistribution. You may reproduce and distribute copies of the
        Work or Derivative Works thereof in any medium, with or without
        modifications, and in Source or Object form, provided that You
        meet the following conditions:

        (a) You must give any other recipients of the Work or
            Derivative Works a copy of this License; and

        (b) You must cause any modified files to carry prominent notices
            stating that You changed the files; and

        (c) You must retain, in the Source form of any Derivative Works
            that You distribute, all copyright, patent, trademark, and
            attribution notices from the Source form of the Work,
            excluding those notices that do not pertain to any part of
            the Derivative Works; and

        (d) If the Work includes a "NOTICE" text file as part of its
            distribution, then any Derivative Works that You distribute must
            include a readable copy of the attribution notices contained
            within such NOTICE file, excluding those notices that do not
            pertain to any part of the Derivative Works, in at least one
            of the following places: within a NOTICE text file distributed
            as part of the Derivative Works; within the Source form or
            documentation, if provided along with the Derivative Works; or,
            within a display generated by the Derivative Works, if and
            wherever such third-party notices normally appear. The contents
            of the NOTICE file are for informational purposes only and
            do not modify the License. You may add Your own attribution
            notices within Derivative Works that You distribute, alongside
            or as an addendum to the NOTICE text from the Work, provided
            that such additional attribution notices cannot be construed
            as modifying the License.

        You may add Your own copyright statement to Your modifications and
        may provide additional or different license terms and conditions
        for use, reproduction, or distribution of Your modifications, or
        for any such Derivative Works as a whole, provided Your use,
        reproduction, and distribution of the Work otherwise complies with
        the conditions stated in this License.

     5. Submission of Contributions. Unless You explicitly state otherwise,
        any Contribution intentionally submitted for inclusion in the Work
        by You to the Licensor shall be under the terms and conditions of
        this License, without any additional terms or conditions.
        Notwithstanding the above, nothing herein shall supersede or modify
        the terms of any separate license agreement you may have executed
        with Licensor regarding such Contributions.

     6. Trademarks. This License does not grant permission to use the trade
        names, trademarks, service marks, or product names of the Licensor,
        except as required for reasonable and customary use in describing the
        origin of the Work and reproducing the content of the NOTICE file.

     7. Disclaimer of Warranty. Unless required by applicable law or
        agreed to in writing, Licensor provides the Work (and each
        Contributor provides its Contributions) on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
        implied, including, without limitation, any warranties or conditions
        of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
        PARTICULAR PURPOSE. You are solely responsible for determining the
        appropriateness of using or redistributing the Work and assume any
        risks associated with Your exercise of permissions under this License.

     8. Limitation of Liability. In no event and under no legal theory,
        whether in tort (including negligence), contract, or otherwise,
        unless required by applicable law (such as deliberate and grossly
        negligent acts) or agreed to in writing, shall any Contributor be
        liable to You for damages, including any direct, indirect, special,
        incidental, or consequential damages of any character arising as a
        result of this License or out of the use or inability to use the
        Work (including but not limited to damages for loss of goodwill,
        work stoppage, computer failure or malfunction, or any and all
        other commercial damages or losses), even if such Contributor
        has been advised of the possibility of such damages.

     9. Accepting Warranty or Additional Liability. While redistributing
        the Work or Derivative Works thereof, You may choose to offer,
        and charge a fee for, acceptance of support, warranty, indemnity,
        or other liability obligations and/or rights consistent with this
        License. However, in accepting such obligations, You may act only
        on Your own behalf and on Your sole responsibility, not on behalf
        of any other Contributor, and only if You agree to indemnify,
        defend, and hold each Contributor harmless for any liability
        incurred by, or claims asserted against, such Contributor by reason
        of your accepting any such warranty or additional liability.

     END OF TERMS AND CONDITIONS

     APPENDIX: How to apply the Apache License to your work.

        To apply the Apache License to your work, attach the following
        boilerplate notice, with the fields enclosed by brackets "[]"
        replaced with your own identifying information. (Don't include
        the brackets!)  The text should be enclosed in the appropriate
        comment syntax for the file format. We also recommend that a
        file or class name and description of purpose be included on the
        same "printed page" as the copyright notice for easier
        identification within third-party archives.

     Copyright [yyyy] [name of copyright owner]

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

         http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.


 WODEN SUBCOMPONENTS:
 For any subcomponents included with the Woden source code that contain
 separate copyright and license terms, their License information is appended
 below, in this file.
 For any binary subcomponents redistributed with Woden under separate
 licenses, their license files are included alongside those binary packages
 in the Woden release files (for example, alongside the dependant jar files
 in the /lib directory of the Woden zip file).

 ===========================================================================

 For the W3C schema and DTD files in the org.apache.woden.resolver package:

 W3C® SOFTWARE NOTICE AND LICENSE
 http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231
 This work (and included software, documentation such as READMEs, or other
 related items) is being provided by the copyright holders under the following
 license. By obtaining, using and/or copying this work, you (the licensee) agree
 that you have read, understood, and will comply with the following terms and
 conditions.

 Permission to copy, modify, and distribute this software and its documentation,
 with or without modification, for any purpose and without fee or royalty is
 hereby granted, provided that you include the following on ALL copies of the
 software and documentation or portions thereof, including modifications:

     The full text of this NOTICE in a location viewable to users of the
     redistributed or derivative work.

     Any pre-existing intellectual property disclaimers, notices, or terms and
     conditions. If none exist, the W3C Software Short Notice should be included
     (hypertext is preferred, text is permitted) within the body of any redistributed
     or derivative code.

     Notice of any changes or modifications to the files, including the date changes
     were made. (We recommend you provide URIs to the location from which the code is
     derived.)

 THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND COPYRIGHT HOLDERS MAKE NO
 REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
 WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE
 OF THE SOFTWARE OR DOCUMENTATION WILL NOT INFRINGE ANY THIRD PARTY PATENTS,
 COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS.

 COPYRIGHT HOLDERS WILL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL OR
 CONSEQUENTIAL DAMAGES ARISING OUT OF ANY USE OF THE SOFTWARE OR DOCUMENTATION.

 The name and trademarks of copyright holders may NOT be used in advertising or
 publicity pertaining to the software without specific, written prior permission.
 Title to copyright in this software and any associated documentation will at all
 times remain with copyright holders.
 ____________________________________

 This formulation of W3C's notice and license became active on December 31 2002.
 This version removes the copyright ownership notice such that this license can
 be used with materials other than those owned by the W3C, reflects that ERCIM is
 now a host of the W3C, includes references to this specific dated version of the
 license, and removes the ambiguous grant of "use". Otherwise, this version is the
 same as the previous version and is written so as to preserve the Free Software
 Foundation's assessment of GPL compatibility and OSI's certification under the
 Open Source Definition. Please see our Copyright FAQ for common questions about
 using materials from our site, including specific terms and conditions for packages
 like libwww, Amaya, and Jigsaw. Other questions about this notice can be directed
 to site-policy@w3.org.

 Joseph Reagle <site-policy@w3.org>

 Last revised $Id: copyright-software-20021231.html,v 1.11 2004/07/06 16:02:49 slesch Exp $

 ===========================================================================

JLine:

Copyright (c) 2002-2006, Marc Prud'hommeaux <mwp1@cornell.edu>
All rights reserved.

Redistribution and use in source and binary forms, with or
without modification, are permitted provided that the following
conditions are met:

Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with
the distribution.

Neither the name of JLine nor the names of its contributors
may be used to endorse or promote products derived from this
software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING,
BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
OF THE POSSIBILITY OF SUCH DAMAGE.

